from scrapy.spiders import Spider
from wk1scrapy.items import Wk1ScrapyItem

class WeatherSpider(Spider):
    name = '2345weather'
    start_urls = ['http://tianqi.2345.com/wea_forty/60220.htm?time=1619107200']

    def parse(self, response):
        # titles = response.xpath("//ul[@class = 'item-box wea-white-icon']")
        titles = response.xpath("//div[@class='main-detail-box']/div[@class='forty-days']/div[@class='forty-days-body']/div[1]//ul[@class='item-box wea-white-icon']")
        item = Wk1ScrapyItem()
        for title in titles:
            item['day'] = title.xpath(".//p[@class = 'day-h']//em[@class='forty-c fr']/text()").extract()[0]

            # print (title.strip())
            item['weather'] = title.xpath('.//p/span[@class = "day-text"]/text()').extract()[0]
            item['temperture'] = title.xpath('.//p/span[@class = "day-tem"]/text()').extract()[0]

            yield item